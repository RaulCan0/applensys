// lib/main.dart
import 'dart:async'; // Necesario para runZonedGuarded y Future
import 'package:flutter/foundation.dart'; // Para kDebugMode y BindingBase
import 'package:flutter/material.dart'; // Para WidgetsFlutterBinding, runApp, MaterialApp, etc.
import 'package:flutter_riverpod/flutter_riverpod.dart'; // Para ProviderScope y ConsumerWidget
import 'package:google_fonts/google_fonts.dart'; // Para temas de fuente
import 'package:supabase_flutter/supabase_flutter.dart'; // Para inicialización de Supabase

// Importaciones de tu proyecto
import 'package:applensys/custom/configurations.dart';
import 'package:applensys/custom/service_locator.dart';
import 'package:applensys/providers/text_size_provider.dart';
import 'package:applensys/providers/theme_provider.dart';
import 'package:applensys/screens/auth/loader_screen.dart';
import 'package:applensys/screens/auth/login_screen.dart';
import 'package:applensys/screens/auth/register_screen.dart';
import 'package:applensys/screens/auth/recoveru_screee.dart';
import 'package:applensys/screens/empresas_screen.dart';
import 'package:applensys/screens/error_screen.dart';
import 'package:applensys/services/domain/notification_service.dart';
import 'package:applensys/services/local/evaluacion_cache_service.dart';

void main() {
  // Asegura que los widgets de Flutter estén inicializados antes de cualquier otra cosa.
  // Esto debe ser la primera llamada para evitar el "Zone mismatch".
  WidgetsFlutterBinding.ensureInitialized();

  // En modo de depuración, puedes hacer que los errores de zona no sean fatales.
  // Esto es útil para desarrollo, pero en producción, es mejor que sean fatales.
  if (kDebugMode) {
    BindingBase.debugZoneErrorsAreFatal = false;
  }

  // runZonedGuarded captura cualquier error no manejado en la aplicación,
  // redirigiéndolos a un ErrorScreen para una mejor experiencia de usuario.
  runZonedGuarded<Future<void>>(
    () async {
      // Configura FlutterError.onError para enviar errores a la zona actual.
      // Esto permite que runZonedGuarded los capture.
      FlutterError.onError = (FlutterErrorDetails details) {
        FlutterError.presentError(details); // Presenta el error en la consola de depuración
        Zone.current.handleUncaughtError(details.exception, details.stack!); // Pasa el error a la zona
      };

      // Inicializaciones asíncronas de servicios.
      await Supabase.initialize(
        url: Configurations.mSupabaseUrl,
        anonKey: Configurations.mSupabaseKey,
      );
      await NotificationService.init();
      setupLocator(); // Configura el Service Locator
      await locator<EvaluacionCacheService>().init(); // Inicializa el servicio de caché

      // Ejecuta la aplicación principal, envolviéndola en ProviderScope para Riverpod.
      runApp(const ProviderScope(child: MyApp()));
    },
    // Callback para manejar errores no capturados.
    (Object error, StackTrace stack) {
      // Si ocurre un error fatal, muestra la pantalla de error.
      runApp(
        ProviderScope(
          child: ErrorScreen(error: error, stackTrace: stack),
        ),
      );
    },
  );
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Observa los providers de tema y tamaño de texto de Riverpod.
    final themeMode = ref.watch(themeModeProvider);
    final textSize = ref.watch(textSizeProvider);
    // Calcula el factor de escala para el texto.
    final scaleFactor = textSize / 14.0; // 14.0 es un tamaño base de texto común

    return MaterialApp(
      debugShowCheckedModeBanner: false, // Oculta el banner de "Debug"
      title: 'LensysApp',
      themeMode: themeMode, // Aplica el tema seleccionado (claro u oscuro)
      
      // Builder para aplicar el escalado de texto globalmente.
      builder: (context, child) {
        // Asegúrate de que child no sea nulo antes de pasarlo a MediaQuery.
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(scaleFactor)),
          child: child!, // Usamos ! para afirmar que child no será nulo
        );
      },

      // Definición del tema claro.
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF003056), // Color primario para el tema claro
        scaffoldBackgroundColor: Colors.white, // Fondo del Scaffold
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF003056),
          foregroundColor: Colors.white, // Color del texto y íconos en el AppBar
        ),
        // Aplica la fuente Google Fonts "Roboto" al tema de texto.
        textTheme: GoogleFonts.robotoTextTheme(
          ThemeData.light().textTheme,
        ),
      ),

      // Definición del tema oscuro.
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color.fromARGB(255, 0, 0, 0), // Color primario para el tema oscuro
        scaffoldBackgroundColor: const Color.fromARGB(75, 206, 206, 206), // Fondo del Scaffold
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black, // Color del texto y íconos en el AppBar
        ),
        // Aplica la fuente Google Fonts "Roboto" al tema de texto.
        textTheme: GoogleFonts.robotoTextTheme(
          ThemeData.dark().textTheme,
        ),
      ),

      // Definición de rutas nombradas para la navegación.
      routes: {
        '/loaderScreen': (_) => const LoaderScreen(),
        '/login': (_) => const LoginScreen(),
        '/register': (_) => const RegisterScreen(),
        '/recovery': (_) => const RecoveryScreen(),
        '/empresas': (_) => const EmpresasScreen(),
      },
      // La pantalla inicial de la aplicación.
      home: const LoaderScreen(),
    );
  }
}