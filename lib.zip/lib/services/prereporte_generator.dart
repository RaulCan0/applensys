import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:docx_template/docx_template.dart';
import 'package:applensys/providers/app_provider.dart';

class PrereporteGenerator {
  /// Ruta al template de prereporte en formato .docx dentro de assets/templates
  static const _templatePath = 'assets/templates/prereporte_template.docx';

  /// Genera un documento .docx editable con todos los prereportes
  Future<Uint8List> generateDocx(
    AppProvider appProv,
    String evaluacionId, {
    required String estructuraJson,
    required String benchT1,
    required String benchT2,
    required String benchT3,
  }) async {
    // 1) Cargar template
    final templateData = await rootBundle.load(_templatePath);
    final template = await DocxTemplate.fromBytes(
      templateData.buffer.asUint8List(),
    );

    // 2) Cargar JSON de estructura y benchmarks
    final estructuraRaw = await rootBundle.loadString(estructuraJson);
    final t1Raw = await rootBundle.loadString(benchT1);
    final t2Raw = await rootBundle.loadString(benchT2);
    final t3Raw = await rootBundle.loadString(benchT3);
    final estructura = json.decode(estructuraRaw) as Map<String, dynamic>;
    final bench1 = json.decode(t1Raw) as List<dynamic>;
    final bench2 = json.decode(t2Raw) as List<dynamic>;
    final bench3 = json.decode(t3Raw) as List<dynamic>;

    // 3) Construir contextos para el template
    final List<Content> dimSections = [];

    for (final dimJson in estructura['dimensiones'] as List<dynamic>) {
      final dimName = dimJson['nombre'] as String;
      dimSections.add(ParagraphContent('Pre-reporte - $dimName'));

      // Tabla de comportamientos
      final tableRows = <TableRowContent>[];
      for (final prJson in (dimJson['principios'] as List<dynamic>)) {
        for (final comp in (prJson['comportamientos'] as List<dynamic>).cast<String>()) {
          // obtener datos de AppProvider
          final fila = appProv.tablaDatos[dimJson['id'].toString()]?[evaluacionId]
              ?.firstWhere((f) => f['benchmark_comportamiento'] == comp);
          final pe = (fila?['valor'] as num?)?.round() ?? 0;
          final pg = (fila?['valorGerente'] as num?)?.round() ?? 0;
          final pm = (fila?['valorEquipo'] as num?)?.round() ?? 0;
          final systemsE = fila?['sistemasEjecutivo'] as List<dynamic>? ?? [];
          final systemsG = fila?['sistemasGerente'] as List<dynamic>? ?? [];
          final systemsM = fila?['sistemasMiembro'] as List<dynamic>? ?? [];

          // funciones auxiliares
          String _getC(String c) {
            return (bench1.firstWhere((e) => e['BENCHMARK DE COMPORTAMIENTOS'].toString().startsWith(comp))[c] ?? '') as String;
          }
          String _getBenchmarkLevel(String nivel) {
            final benchList = nivel == 'Ejecutivo' ? bench1 : nivel == 'Gerente' ? bench2 : bench3;
            return (benchList.firstWhere(
                (e) => e['BENCHMARK DE COMPORTAMIENTOS'].toString().startsWith(comp))['BENCHMARK POR NIVEL]'] ?? '') as String;
          }

          // Agregar 3 filas para cada nivel
          for (final nivel in ['Ejecutivo', 'Gerente', 'Equipo']) {
            final valor = nivel == 'Ejecutivo' ? pe : nivel == 'Gerente' ? pg : pm;
            final sistemas = nivel == 'Ejecutivo'
                ? systemsE
                : nivel == 'Gerente'
                    ? systemsG
                    : systemsM;
            final resultadoC = _getC('C\$valor');
            final benchLevel = _getBenchmarkLevel(nivel);

            tableRows.add(
              TableRowContent(
                cells: [
                  ParagraphContent(comp),
                  ParagraphContent(valor.toString()),
                  ParagraphContent(nivel),
                  ParagraphContent(sistemas.join(', ')),
                  ParagraphContent(resultadoC),
                  ParagraphContent(benchLevel),
                ],
              ),
            );
          }
        }
      }

      dimSections.add(TableContent(
        rows: tableRows,
        widths: [2, 1, 1, 2, 3, 3],
      ));
    }

    // 4) Generar documento
    final content = Content();
    content.addAll({'sections': ColumnContent(dimSections)});
    final out = await template.generate(content);
    if (out == null) {
      throw Exception('Error al generar el documento .docx');
    }
    return out;
  }
}
