import 'dart:io' show File;

import 'package:docx_template/docx_template.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

Future<File> generarWord({
  required String empresa,
  required String ubicacion,
  required Uint8List portadaBytes,
  required List<Uint8List> graficosDashboard,
  required List<Map<String, dynamic>> datosComportamientos,
}) async {
  // 1) Carga la plantilla .docx desde assets
  final bytes = await rootBundle.load('assets/plantilla_prereporte.docx');
  final doc = await DocxTemplate.fromBytes(bytes.buffer.asUint8List());

  // Helper para asegurar bytes válidos
  // ignore: no_leading_underscores_for_local_identifiers
  Uint8List _toBytes(dynamic raw) {
    if (raw is Uint8List) return raw;
    if (raw is List<int>) return Uint8List.fromList(raw);
    return Uint8List(0); // fallback a imagen vacía
  }

  // 2) Prepara el contenido principal
  final content = Content()
    ..add(TextContent('empresa', empresa))
    ..add(TextContent('ubicacion', ubicacion))
    ..add(ImageContent('portada', portadaBytes));

  // 3) Sección GRÁFICOS
  final listaGraficos = graficosDashboard.map((b) {
    return Content()..add(ImageContent('grafico', _toBytes(b)));
  }).toList();
  content.add(ListContent('graficos', listaGraficos));

  // 4) Sección COMPORTAMIENTOS
  final listaComportamientos = datosComportamientos.map((r) {
    final nivelesList = ['ejecutivo', 'gerente', 'm.equipo'].map((nivel) {
      final entry = (r[nivel] as Map<String, dynamic>?) ?? {};
      return Content()
        ..add(TextContent('nivel', nivel.toUpperCase()))
        ..add(TextContent('resultado',
            (entry['resultado'] as num? ?? 0).toStringAsFixed(2)))
        ..add(TextContent(
            'sistemas',
            (entry['sistemas'] is List)
                ? List<String>.from(entry['sistemas']).join(', ')
                : (entry['sistemas']?.toString() ?? '')))
        ..add(TextContent('hallazgos', entry['hallazgos'] ?? ''))
        ..add(TextContent('interpretacion', entry['interpretacion'] ?? ''))
        ..add(TextContent('benchmark', entry['benchmark'] ?? ''));
    }).toList();

    final rawGraf = r['grafico'];
    final graficoBytes = _toBytes(rawGraf);

    return Content()
      ..add(TextContent('titulo', r['titulo'] ?? ''))
      ..add(TextContent('definicion', r['definicion'] ?? ''))
      ..add(ListContent('niveles', nivelesList))
      ..add(ImageContent('grafico_comportamiento', graficoBytes));
  }).toList();
  content.add(ListContent('comportamientos', listaComportamientos));

  // 5) Genera el .docx y lo guarda en temp
  final generated = await doc.generate(content);
  final dir = await getTemporaryDirectory();
  final outFile = File('${dir.path}/prereporte.docx');
  if (generated != null) {
    await outFile.writeAsBytes(generated);
  }
  return outFile;
}
