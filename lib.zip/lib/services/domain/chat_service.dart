import 'package:applensys/models/message.dart';


class ChatService {
  Future<void> sendMessage(String userId, String content) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }

  Stream<List<Message>> messageStream() {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }
}