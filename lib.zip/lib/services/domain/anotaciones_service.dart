// anotaciones_service.dart

class AnotacionesService {
  // Stream de anotaciones
  Stream<List<Map<String, dynamic>>> streamAnotaciones() {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }

  // Agregar anotación
  Future<void> agregarAnotacion({
    required String titulo,
    String? contenido,
    String? archivoPath,
  }) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }

  // Eliminar anotación
  Future<void> eliminarAnotacion(int id) async {
    // Implementación pendiente o ajustada según necesidades
    throw UnimplementedError();
  }
}
