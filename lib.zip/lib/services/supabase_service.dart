import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;

  // ===================== EMPRESAS =====================
  Future<List<Map<String, dynamic>>> getEmpresas() async {
    final response = await _client.from('empresas').select();
    return response;
  }

  Future<void> addEmpresa({
    required String nombre,
    required String tamano,
    required int empleadosTotal,
    required String unidades,
    required int areas,
    required String sector,
  }) async {
    await _client.from('empresas').insert({
      'nombre': nombre,
      'tamano': tamano,
      'empleados_total': empleadosTotal,
      'unidades': unidades,
      'areas': areas,
      'sector': sector,
    });
  }

  Future<void> updateEmpresa(String id, Map<String, dynamic> data) async {
    await _client.from('empresas').update(data).eq('id', id);
  }

  Future<void> deleteEmpresa(String id) async {
    await _client.from('empresas').delete().eq('id', id);
  }

  // ===================== ASOCIADOS =====================
  Future<List<Map<String, dynamic>>> getAsociadosPorEmpresa(
    String empresaId,
  ) async {
    final response = await _client
        .from('asociados')
        .select()
        .eq('empresa_id', empresaId);
    return response;
  }

  Future<void> addAsociado({
    required String nombre,
    required String cargo,
    required String empresaId,
  }) async {
    await _client.from('asociados').insert({
      'nombre': nombre,
      'cargo': cargo,
      'empresa_id': empresaId,
    });
  }

  Future<void> updateAsociado(String id, Map<String, dynamic> data) async {
    await _client.from('asociados').update(data).eq('id', id);
  }

  Future<void> deleteAsociado(String id) async {
    await _client.from('asociados').delete().eq('id', id);
  }

  // ===================== EVALUACIONES =====================
  Future<List<Map<String, dynamic>>> getEvaluaciones() async {
    final response = await _client.from('detalles_evaluacion').select();
    return response;
  }

  Future<Map<String, dynamic>> addEvaluacion({
    required String empresa,
    required String consultor,
  }) async {
    final result =
        await _client
            .from('detalles_evaluacion')
            .insert({'empresa': empresa, 'consultor': consultor})
            .select()
            .single();

    return result;
  }

  Future<void> updateEvaluacion(String id, Map<String, dynamic> data) async {
    await _client.from('detalles_evaluacion').update(data).eq('id', id);
  }

  Future<void> deleteEvaluacion(String id) async {
    await _client.from('detalles_evaluacion').delete().eq('id', id);
  }

  // ===================== CALIFICACIONES =====================
  Future<void> addCalificacion({
    required String idAsociado,
    required String criterio,
    required int puntaje,
  }) async {
    await _client.from('calificaciones').insert({
      'id_asociado': idAsociado,
      'criterio': criterio,
      'puntaje': puntaje,
    });
  }

  Future<List<Map<String, dynamic>>> getCalificacionesPorAsociado(
    String idAsociado,
  ) async {
    final response = await _client
        .from('calificaciones')
        .select()
        .eq('id_asociado', idAsociado);
    return response;
  }

  Future<void> updateCalificacion(String id, int nuevoPuntaje) async {
    await _client
        .from('calificaciones')
        .update({'puntaje': nuevoPuntaje})
        .eq('id', id);
  }

  Future<void> deleteCalificacion(String id) async {
    await _client.from('calificaciones').delete().eq('id', id);
  }
}
