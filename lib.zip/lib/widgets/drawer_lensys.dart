// ignore_for_file: use_build_context_synchronously

import 'package:applensys/models/empresa.dart';
import 'package:applensys/screens/auth/loader_screen.dart';
import 'package:applensys/screens/dashboard_screen.dart';
import 'package:applensys/screens/detalles_evaluacion.dart';
import 'package:applensys/screens/empresas_screen.dart';
import 'package:applensys/screens/historial_screen.dart';
import 'package:applensys/screens/perfil_screen.dart';
import 'package:applensys/screens/tablas_screen.dart';
import 'package:applensys/services/supabase_service.dart';
import 'package:applensys/widgets/chat_scren.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../screens/anotaciones_screen.dart';

class DrawerLensys extends StatelessWidget {
  const DrawerLensys({super.key});

  Future<Map<String, dynamic>> _getUserData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return {'nombre': 'Usuario', 'foto_url': null};
    final data = await Supabase.instance.client
        .from('usuarios')
        .select('nombre, foto_url')
        .eq('id', user.id)
        .single();
    return {
      'nombre': data['nombre'] ?? 'Usuario',
      'foto_url': data['foto_url'],
    };
  }

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    final userEmail = user?.email ?? 'usuario@ejemplo.com';
    final fontProvider = Provider.of<FontProvider>(context, listen: false);

    return Drawer(
      child: Container(
        color: Colors.white,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            FutureBuilder<Map<String, dynamic>>(
              future: _getUserData(),
              builder: (context, snapshot) {
                final nombre = snapshot.data?['nombre'] ?? 'Usuario';
                final fotoUrl = snapshot.data?['foto_url'];
                return UserAccountsDrawerHeader(
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 35, 47, 112),
                  ),
                  accountName: Text(nombre, style: const TextStyle(fontSize: 18)),
                  accountEmail: Text(userEmail),
                  currentAccountPicture: (fotoUrl != null && fotoUrl != '')
                      ? CircleAvatar(backgroundImage: NetworkImage(fotoUrl))
                      : const CircleAvatar(
                          backgroundColor: Colors.white,
                          child: Icon(Icons.person, size: 40, color: Color.fromARGB(255, 35, 47, 112)),
                        ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.home, color: Colors.black),
              title: const Text("Inicio"),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const EmpresasScreen()),
                  (route) => false,
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.table_chart, color: Colors.black),
              title: const Text("Resultados"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => TablasDimensionScreen(
                      empresa: Empresa(
                        id: 'defaultId',
                        nombre: 'Default Empresa',
                        tamano: 'Default Tamano',
                        empleadosTotal: 0,
                        empleadosAsociados: [],
                        unidades: 'Default Unidades',
                        areas: 0,
                        sector: 'Default Sector',
                        createdAt: DateTime.now(),
                      ),
                      dimension: 'defaultDimension',
                      empresaId: '',
                      evaluacionId: '',
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_chart, color: Colors.black),
              title: const Text("Detalle Evaluación"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DetallesEvaluacionScreen(
                      dimensionesPromedios: const {},
                      promedios: const {},
                      empresa: Empresa(
                        id: '',
                        nombre: '',
                        tamano: '',
                        empleadosTotal: 0,
                        empleadosAsociados: [],
                        unidades: '',
                        areas: 0,
                        sector: '',
                        createdAt: DateTime.now(),
                      ),
                      evaluacionId: '',
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history, color: Colors.black),
              title: const Text("Historial"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => HistorialScreen(
                      empresas: [],
                      empresasHistorial: [],
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.person, color: Colors.black),
              title: const Text("Perfil"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PerfilScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.dashboard, color: Colors.black),
              title: const Text("Dashboard"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DashboardScreen(
                      empresa: Empresa(
                        id: '',
                        nombre: '',
                        tamano: '',
                        empleadosTotal: 0,
                        empleadosAsociados: [],
                        unidades: '',
                        areas: 0,
                        sector: '',
                        createdAt: DateTime.now(),
                      ),
                      evaluacionId: '',
                    ),
                  ),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.chat, color: Colors.black),
              title: const Text("Chat"),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ChatWidgetDrawer()),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.note_add),
              title: const Text('Mis Anotaciones'),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => AnotacionesScreen(userId: Supabase.instance.client.auth.currentUser!.id),
                  ),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.text_fields, color: Colors.black),
              title: const Text("Tamaño de letra"),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Ajustar tamaño de letra'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ElevatedButton(
                          onPressed: () => fontProvider.setScale(0.9),
                          child: const Text("Pequeño"),
                        ),
                        ElevatedButton(
                          onPressed: () => fontProvider.setScale(1.0),
                          child: const Text("Medio"),
                        ),
                        ElevatedButton(
                          onPressed: () => fontProvider.setScale(1.2),
                          child: const Text("Grande"),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text("Cerrar sesión", style: TextStyle(color: Colors.red)),
              onTap: () async {
                final supabaseService = SupabaseService();
                await supabaseService.signOut();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoaderScreen()),
                  (route) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}