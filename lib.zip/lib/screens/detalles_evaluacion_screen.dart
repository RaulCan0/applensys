import 'package:applensys/models/empresa.dart';
import 'package:flutter/material.dart';
import 'tablas_screen.dart';
import 'package:applensys/services/local/evaluacion_cache_service.dart';

class DetallesEvaluacionScreen extends TablasDimensionScreen {
  const DetallesEvaluacionScreen({
    super.key,
    // ignore: type_init_formals
    required Empresa super.empresa,
    required super.evaluacionId,
    required super.asociadoId,
    required super.empresaId,
    required super.dimension,
  });

  @override
  State<DetallesEvaluacionScreen> createState() => _DetallesEvaluacionScreenState();
}

class _DetallesEvaluacionScreenState extends State<DetallesEvaluacionScreen> {
  @override
  void initState() {
    super.initState();
    // Aquí puedes agregar lógica específica para DetallesEvaluacionScreen
  }

  void sincronizarConServicio() {
    // Ejemplo de comunicación con un servicio centralizado
    EvaluacionCacheService().guardarTablas(TablasDimensionScreen.tablaDatos);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalles Evaluación'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Detalles de la evaluación'),
            ElevatedButton(
              onPressed: sincronizarConServicio,
              child: const Text('Sincronizar con servicio'),
            ),
          ],
        ),
      ),
    );
  }
}
