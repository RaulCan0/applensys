import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:share_plus/share_plus.dart';
import 'package:fl_chart/fl_chart.dart';

import 'package:applensys/models/empresa.dart';
import 'package:applensys/models/calificacion.dart';
import 'package:applensys/providers/app_provider.dart';
import 'package:applensys/services/excel_exporter.dart';
import 'package:applensys/services/evaluacion_preferences.dart';
import '../widgets/drawer_lensys.dart';

class DetallesEvaluacionScreen extends StatefulWidget {
  final Empresa empresa;
  final String evaluacionId;

  const DetallesEvaluacionScreen({
    super.key,
    required this.empresa,
    required this.evaluacionId, required Map<String, Map<String, double>> dimensionesPromedios,
  });

  @override
  State<DetallesEvaluacionScreen> createState() => _DetallesEvaluacionScreenState();
}

class _DetallesEvaluacionScreenState extends State<DetallesEvaluacionScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  bool _isGenerating = false;
  bool _isExporting = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalles Evaluación'),
        bottom: TabBar(
          controller: _tabController,
          tabs: _appProv.progresoDimensiones.keys
              .map((key) => Tab(text: key))
              .toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: _appProv.progresoDimensiones.keys.map((key) {
          return Center(
            child: Text('Contenido para $key'),
          );
        }).toList(),
      ),
    );
  }

  late final AppProvider _appProv;
  late final EvaluacionPreferences _prefs;

  @override
  void initState() {
    super.initState();
    _appProv = Provider.of<AppProvider>(context, listen: false);
    _prefs = EvaluacionPreferences();
    _tabController = TabController(
      length: _appProv.progresoDimensiones.keys.length,
      vsync: this,
    );
    _loadData();
  }

  Future<void> _loadData() async {
    await _appProv.loadProgresoDimensiones(widget.empresa.id);
    await _appProv.loadTablaDatos(widget.empresa.id);
    await _prefs.load();
      // Construir systemsMap a partir de tablaDatos
      final Map<String, List<String>> systemsMap = {};
      _appProv.tablaDatos.forEach((dim, evals) {
        evals[widget.evaluacionId]?.forEach((fila) {
          final comp = fila['benchmark_comportamiento'] as String;
          final nivel = fila['nivel'] as String;
          systemsMap['\$nivel:\$comp'] = List<String>.from(fila['sistemas'] as List);
        });
      });
      // Generar prereporte usando generateDocx
      final bytes = await PrereporteGenerator().generatePdf(
        superEval: _appProv,
        sistemasPorNivel: systemsMap,
      );
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/prereporte_${widget.evaluacionId}.docx'; '${dir.path}/prereporte_${widget.evaluacionId}.docx';
