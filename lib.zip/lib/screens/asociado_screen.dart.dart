import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/asociado.dart';
import '../../models/empresa.dart';
import 'principios_screen.dart';

class AsociadoScreen extends StatefulWidget {
  final Empresa empresa;
  final String dimensionId;

  const AsociadoScreen({
    super.key,
    required this.empresa,
    required this.dimensionId,
  });

  @override
  State<AsociadoScreen> createState() => _AsociadoScreenState();
}

class _AsociadoScreenState extends State<AsociadoScreen> {
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _antiguedadController = TextEditingController();
  String _cargo = 'ejecutivo';

  @override
  Widget build(BuildContext context) {
    final asociadosEmpresa = widget.empresa.empleadosAsociados;

    return Scaffold(
      appBar: AppBar(
        title: Text('Asociados - ${widget.empresa.nombre}'),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 4,
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    TextField(
                      controller: _nombreController,
                      decoration: const InputDecoration(
                        labelText: 'Nombre del asociado',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _antiguedadController,
                            decoration: const InputDecoration(
                              labelText: 'Antigüedad (años)',
                              border: OutlineInputBorder(),
                            ),
                            keyboardType: TextInputType.number,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _cargo,
                            onChanged:
                                (value) => setState(() => _cargo = value!),
                            items:
                                ['ejecutivo', 'gerente', 'miembro de equipo']
                                    .map(
                                      (cargo) => DropdownMenuItem(
                                        value: cargo,
                                        child: Text(cargo.toUpperCase()),
                                      ),
                                    )
                                    .toList(),
                            decoration: const InputDecoration(
                              labelText: 'Cargo',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        final nombre = _nombreController.text.trim();
                        final antiguedad = _antiguedadController.text.trim();
                        if (nombre.isNotEmpty && antiguedad.isNotEmpty) {
                          final nuevo = Asociado(
                            id: const Uuid().v4(),
                            nombre: nombre,
                            cargo: _cargo,
                            empresaId: widget.empresa.id,
                          );
                          setState(() {
                            widget.empresa.empleadosAsociados.add(nuevo);
                          });
                          _nombreController.clear();
                          _antiguedadController.clear();
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                      ),
                      child: const Text(
                        'Asociar empleado',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Asociados:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: asociadosEmpresa.length,
                itemBuilder: (_, index) {
                  final asociado = asociadosEmpresa[index];
                  return Card(
                    child: ListTile(
                      title: Text(asociado.nombre),
                      subtitle: Text(asociado.cargo.toUpperCase()),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => PrincipiosScreen(
                                  empresa: widget.empresa,
                                  asociado: asociado,
                                  dimensionId: widget.dimensionId,
                                ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
