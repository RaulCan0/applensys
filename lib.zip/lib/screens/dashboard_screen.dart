import 'package:applensys/services/local/evaluacion_cache_service.dart';
import 'package:applensys/services/evaluacion_chart_data_final.dart';
import 'package:flutter/material.dart';
import 'package:applensys/models/empresa.dart';
import 'package:applensys/models/dimension.dart';
import 'package:applensys/models/principio.dart';
import 'package:applensys/models/comportamiento.dart';
import 'package:applensys/widgets/drawer_lensys.dart';
import 'package:applensys/charts/donut_chart.dart';
import 'package:applensys/charts/scatter_bubble_chart.dart';
import 'package:applensys/charts/grouped_bar_chart.dart';
import 'package:applensys/charts/horizontal_bar_systems_chart.dart';

class DashboardScreen extends StatefulWidget {
  final Empresa empresa;
  final String evaluacionId;

  const DashboardScreen({
    super.key,
    required this.empresa,
    required this.evaluacionId,
  });

  @override
  // ignore: library_private_types_in_public_api
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<List<Dimension>> _datosFuture;

  @override
  void initState() {
    super.initState();
    _datosFuture = _cargarDatos();
  }

  Future<List<Dimension>> _cargarDatos() async {
    final service = EvaluacionCacheService();
    await service.init();
    final tablas = await service.cargarTablas();

    final dimensionesList = <Map<String, dynamic>>[];

    for (final dimEntry in tablas.entries) {
      final filas = dimEntry.value[widget.evaluacionId] ?? [];
      if (filas.isEmpty) continue;

      // Agrupar por principio
      final principiosMap = <String, List<Map<String, dynamic>>>{};
      for (final fila in filas) {
        final princ = fila['principio'] as String? ?? 'SinPrincipio';
        principiosMap.putIfAbsent(princ, () => []).add(fila);
      }

      final principiosList = principiosMap.entries.map((e) {
        // Agrupar por comportamiento dentro de cada principio
        final comportamientosMap = <String, List<Map<String, dynamic>>>{};
        for (final fila in e.value) {
          final comp = fila['comportamiento'] as String? ?? 'SinComportamiento';
          comportamientosMap.putIfAbsent(comp, () => []).add(fila);
        }

        final comps = comportamientosMap.entries.map((ce) {
          double sumaEj = 0, sumaGe = 0, sumaMi = 0;
          int countEj = 0, countGe = 0, countMi = 0;
          List<String> sistemas = [];
          String cargo = '';
          for (final fila in ce.value) {
            final valor = (fila['valor'] as num?)?.toDouble() ?? 0.0;
            final cargoRaw = (fila['cargo'] as String? ?? fila['cargo_raw'] as String? ?? '').toLowerCase();
            cargo = cargoRaw.contains('ejecutivo')
                ? 'Ejecutivo'
                : cargoRaw.contains('gerente')
                    ? 'Gerente'
                    : cargoRaw.contains('miembro')
                        ? 'Miembro'
                        : '';
            if (cargo == 'Ejecutivo') {
              sumaEj += valor;
              countEj++;
            } else if (cargo == 'Gerente') {
              sumaGe += valor;
              countGe++;
            } else if (cargo == 'Miembro') {
              sumaMi += valor;
              countMi++;
            }
            // Sistemas asociados
            final sis = (fila['sistemas'] as List?)?.cast<String>() ?? [];
            sistemas.addAll(sis);
          }
          return {
            'nombre': ce.key,
            'ejecutivo': countEj > 0 ? sumaEj / countEj : 0.0,
            'gerente': countGe > 0 ? sumaGe / countGe : 0.0,
            'miembro': countMi > 0 ? sumaMi / countMi : 0.0,
            'sistemas': sistemas.toSet().toList(),
            'cargo': cargo,
          };
        }).toList();

        // Promedio del principio
        double sumaProm = 0;
        int countProm = 0;
        for (final c in comps) {
          final ej = c['ejecutivo'] as double;
          final ge = c['gerente'] as double;
          final mi = c['miembro'] as double;
          int niveles = 0;
          double suma = 0;
          if (ej > 0) {
            suma += ej;
            niveles++;
          }
          if (ge > 0) {
            suma += ge;
            niveles++;
          }
          if (mi > 0) {
            suma += mi;
            niveles++;
          }
          if (niveles > 0) {
            sumaProm += suma / niveles;
            countProm++;
          }
        }
        final promedio = countProm > 0 ? sumaProm / countProm : 0.0;

        return {
          'nombre': e.key,
          'promedio': double.parse(promedio.toStringAsFixed(2)),
          'comportamientos': comps,
        };
      }).toList();

      // Promedio de la dimensión
      double sumaDim = 0;
      int countDim = 0;
      for (final p in principiosList) {
        final prom = (p['promedio'] as num?)?.toDouble() ?? 0.0;
        if (prom > 0) {
          sumaDim += prom;
          countDim++;
        }
      }
      final promedioDimension = countDim > 0 ? sumaDim / countDim : 0.0;

      dimensionesList.add({
        'id': dimEntry.key,
        'nombre': dimEntry.key,
        'promedio': double.parse(promedioDimension.toStringAsFixed(2)),
        'principios': principiosList,
      });
    }

    return EvaluacionChartData.buildDimensionesChartData(dimensionesList);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      endDrawer: const DrawerLensys(),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(widget.empresa.nombre),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
      ),
      body: FutureBuilder<List<Dimension>>(
        future: _datosFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !(snapshot.hasData) || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hay datos disponibles para mostrar', style: TextStyle(fontSize: 16)));
          }
          final dimensiones = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              _buildChartCard(
                title: 'Promedio por Dimensión',
                child: DonutChart(
                  data: {for (final d in dimensiones) d.nombre: d.promedioGeneral},
                  title: 'Promedio por Dimensión',
                ),
              ),
              _buildChartCard(
                title: 'Principios',
                child: ScatterBubbleChart(
                  data: [
                    for (final p in EvaluacionChartData.extractPrincipios(dimensiones))
                      ScatterData(
                        name: p.nombre,
                        value: p.promedioGeneral,
                        x: p.promedioGeneral,
                        y: p.comportamientos.length.toDouble(),
                        radius: p.promedioGeneral * 5,
                        color: Colors.blue.shade300,
                      )
                  ],
                  title: 'Principios',
                ),
              ),
              _buildChartCard(
                title: 'Comportamientos',
                child: GroupedBarChart(
                  data: _buildGroupedBarData(dimensiones),
                  title: 'Comportamientos',
                  minY: 0,
                  maxY: 5,
                ),
              ),
              _buildChartCard(
                title: 'Distribución por Nivel y Sistema',
                child: HorizontalBarSystemsChart(
                  data: _buildHorizontalBarData(dimensiones),
                  title: 'Sistemas',
                  minX: 0,
                  maxX: 5,
                  maxY: 0,
                  minY: 15,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildChartCard({required String title, required Widget child}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SizedBox(height: 300, child: child),
          ],
        ),
      ),
    );
  }

  Map<String, List<double>> _buildGroupedBarData(List<Dimension> dims) {
    final comps = EvaluacionChartData.extractComportamientos(dims).cast<Comportamiento>();
    return {
      for (final c in comps)
        c.nombre: [
          c.promedioEjecutivo.clamp(0, 5),
          c.promedioGerente.clamp(0, 5),
          c.promedioMiembro.clamp(0, 5)
        ]
    };
  }

  Map<String, Map<String, int>> _buildHorizontalBarData(List<Dimension> dims) {
    final sistemasMap = <String, Map<String, int>>{};
    for (final dim in dims) {
      for (final pri in dim.principios) {
        for (final comp in pri.comportamientos) {
          for (final sistema in comp.sistemas) {
            sistemasMap.putIfAbsent(sistema, () => {'Ejecutivo': 0, 'Gerente': 0, 'Miembro': 0});
            sistemasMap[sistema]![comp.cargo] = (sistemasMap[sistema]![comp.cargo] ?? 0) + 1;
          }
        }
      }
    }
    return sistemasMap;
  }
}
