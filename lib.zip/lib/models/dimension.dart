class Dimension {
  final String id;
  final String nombre;

  Dimension({required this.id, required this.nombre});
}