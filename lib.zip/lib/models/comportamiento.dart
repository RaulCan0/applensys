class Comportamiento {
  String nombre;
  int ejecutivo;
  int gerente;
  int miembro;

  Comportamiento({
    required this.nombre,
    this.ejecutivo = 0,
    this.gerente = 0,
    this.miembro = 0,
  });
}
