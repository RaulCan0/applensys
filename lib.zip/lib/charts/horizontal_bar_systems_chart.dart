import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class HorizontalBarSystemsChart extends StatelessWidget {
  final Map<String, Map<String, double>> data;
  final String title;
  final double minX;
  final double maxX;

  const HorizontalBarSystemsChart({
    super.key,
    required this.data,
    required this.title, required this.minX, required this.maxX, required int maxY, required int minY,
  
  });

  @override
  Widget build(BuildContext context) {
    final List<_SystemData> chartData = [];

    // ESTA ES TU LISTA COMPLETA DE SISTEMAS QUE QUIERES MOSTRAR
    final sistemasOrdenados = [
      'Ambiental',
      'Comunicación',
      'Desarrollo de personal',
      'Despliegue de estrategia',
      'Gestion visual',
      'Involucramiento',
      'Medicion',
      'Mejora y alineamiento estratégico',
      'Mejora y gestion visual',
      'Planificacion',
      'Programacion y de mejora',
      'Reconocimiento',
      'Seguridad',
      'Sistemas de mejora',
      'Solucion de problemas',
      'Voz de cliente',
      'Visitas al Gemba'
    ];

    // EL BUCLE ITERA SOBRE TU LISTA COMPLETA
    for (final sistema in sistemasOrdenados) {
      // AQUÍ ESTÁ LA CLAVE:
      // Si data[sistema] no existe (es decir, no hay datos para este 'sistema' en particular),
      // 'niveles' tomará el valor por defecto: {'E': 0.0, 'G': 0.0, 'M': 0.0}
      final niveles = data[sistema] ?? {'E': 0.0, 'G': 0.0, 'M': 0.0};
      
      // POR LO TANTO, SIEMPRE SE AÑADE UN _SystemData PARA CADA 'sistema' DE TU LISTA
      chartData.add(_SystemData(
        sistema, // El nombre del sistema de tu lista
        (niveles['E'] as num).toDouble(), // Será 0.0 si no había datos para 'E'
        (niveles['G'] as num).toDouble(), // Será 0.0 si no había datos para 'G'
        (niveles['M'] as num).toDouble(), // Será 0.0 si no había datos para 'M'
      ));
    }

    // Esta condición solo se cumpliría si 'sistemasOrdenados' estuviera vacía,
    // lo cual no es el caso.
    if (chartData.isEmpty) {
      return const Center(
        child: Text('No hay datos disponibles',
            style: TextStyle(color: Colors.black, fontSize: 16)),
      );
    }

    return SfCartesianChart(
      isTransposed: false,
      zoomPanBehavior: ZoomPanBehavior(
        enablePanning: true,
        zoomMode: ZoomMode.x,
      ),
      plotAreaBorderWidth: 0,
      primaryXAxis: CategoryAxis(
        labelStyle: const TextStyle(color: Colors.black),
        labelRotation: -45,
        labelIntersectAction: AxisLabelIntersectAction.rotate45,
      ),
      primaryYAxis: NumericAxis(
        minimum: 0,
        maximum: 5,
        interval: 1,
        labelStyle: const TextStyle(color: Colors.black),
      ),
      series: <CartesianSeries<_SystemData, String>>[
        BarSeries<_SystemData, String>(
          dataSource: chartData,
          xValueMapper: (d, _) => d.sistema,
          yValueMapper: (d, _) => d.e,
          name: 'Ejecutivo',
          color: Colors.orange,
        ),
        BarSeries<_SystemData, String>(
          dataSource: chartData,
          xValueMapper: (d, _) => d.sistema,
          yValueMapper: (d, _) => d.g,
          name: 'Gerente',
          color: Colors.green,
        ),
        BarSeries<_SystemData, String>(
          dataSource: chartData,
          xValueMapper: (d, _) => d.sistema,
          yValueMapper: (d, _) => d.m,
          name: 'Miembro',
          color: Colors.blue,
        ),
      ],
      legend: Legend(
        isVisible: true,
        position: LegendPosition.bottom,
        textStyle: const TextStyle(color: Colors.black),
      ),
    );
  }
}

class _SystemData {
  final String sistema;
  final double e;
  final double g;
  final double m;

  _SystemData(this.sistema, this.e, this.g, this.m);
}
