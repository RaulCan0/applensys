// lib/charts/donut_chart.dart

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

/// Gráfico de dona (PieChart) con leyenda abajo.
/// Recibe:
///  • data: `Map<nombre_dimension, promedio>`
///  • title: String (título encima del gráfico)
class DonutChart extends StatelessWidget {
  final Map<String, double> data;
  final String title;

  const DonutChart({
    super.key,
    required this.data,
    required this.title, required Map dataMap,
  });

  @override
  Widget build(BuildContext context) {
    final sections = data.entries.map((entry) {
      final val = entry.value;
      return PieChartSectionData(
        value: val,
        title: '', // No mostramos texto dentro de cada sección
        radius: 50,
        showTitle: false,
      );
    }).toList();

    final total = data.values.fold(0.0, (a, b) => a + b);

    return Column(
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Expanded(
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 30,
              sections: sections,
            ),
          ),
        ),
        const SizedBox(height: 8),
        // Leyenda:
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 12,
          runSpacing: 8,
          children: data.entries.map((e) {
            final porcentaje = total > 0
                ? '${(e.value / total * 100).toStringAsFixed(1)}%'
                : '0%';
            final colorIndex =
                data.keys.toList().indexOf(e.key) % Colors.primaries.length;
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 12,
                  height: 12,
                  color: Colors.primaries[colorIndex],
                ),
                const SizedBox(width: 4),
                Text('${e.key} ($porcentaje)'),
              ],
            );
          }).toList(),
        ),
      ],
    );
  }
}
